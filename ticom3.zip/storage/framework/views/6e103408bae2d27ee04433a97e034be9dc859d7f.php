
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-cover" style="background-image:url(<?php echo e(asset('img/banerticom.jpg')); ?>)">
        <div class="px-4 py-40 mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="w-full md:w-3/4 lg:w-1/2">
                <h1 class="text-4xl text-white font-fold">Busca tu Empresa o Producto</h1>
                <p class="mt-2 mb-4 text-lg text-white">Si deseas comprar encontrarás las empresas más solidas.</p>
                <p class="mt-2 mb-4 text-lg text-white">Si deseas vender registrate</p>

                <div class="relative pt-2 mx-auto text-gray-600" autocomplete="off">
                    <input class="w-full h-10 px-5 pr-16 text-sm bg-white border-2 border-gray-300 rounded-lg focus:outline-none"
                    type="search" name="search" placeholder="Search">
                    
                    <button type="submit" class="absolute top-0 right-0 px-4 py-2 mt-2 font-bold text-white bg-blue-500 rounded hover:bg-blue-700">
                        Buscar
                    </button> 
                </div>
            </div>     
        </div>
    </section>

    <section class="mt-16">
        
        <h1 class="mb-6 text-3xl text-center text-gray-600">Ultimas Productos</h1>
        <div class="grid grid-cols-1 px-4 mx-auto max-w-7xl sm:px-6 lg:px-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <article>
                    <figure>
                        <img class="object-cover w-full rounded-xl h-36" src="<?php echo e(asset('img/home/1.jpg')); ?>" alt="">
                    </figure>
                    <header class="mt-2">
                        <h1 class="text-xl text-center text-gray-700"><?php echo e($producto->name); ?></h1>
                    </header>
                   
                </article>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

    </section>


    <section class="mt-16">
        
        <h1 class="mb-6 text-3xl text-center text-gray-600">Ultimas Empresas Registradas</h1>
        <div class="grid grid-cols-1 px-4 mx-auto max-w-7xl sm:px-6 lg:px-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8">
            <?php $__currentLoopData = $bussiness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bussines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <article>
                    <figure>
                        <img class="object-cover w-full rounded-xl h-36" src="<?php echo e(asset('img/home/1.jpg')); ?>" alt="">
                    </figure>
                    <header class="mt-2">
                        <h1 class="text-xl text-center text-gray-700"><?php echo e($bussines->razonsocial); ?></h1>
                    </header>
                   
                </article>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

 <?php /**PATH C:\xampp\htdocs\ticom3\resources\views/welcome.blade.php ENDPATH**/ ?>