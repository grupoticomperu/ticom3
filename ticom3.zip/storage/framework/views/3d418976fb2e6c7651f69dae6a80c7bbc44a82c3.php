<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center">
            <h2 class="text-xl font-semibold leading-tight text-gray-600">
                Lista de Productos  :  
            </h2>
        </div>
     <?php $__env->endSlot(); ?>


    <div class="py-10 mx-auto max-w-7xl sm:px-6 lg:px-8">

       <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('lista-productos')->html();
} elseif ($_instance->childHasBeenRendered('en1h5Aj')) {
    $componentId = $_instance->getRenderedChildComponentId('en1h5Aj');
    $componentTag = $_instance->getRenderedChildComponentTagName('en1h5Aj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('en1h5Aj');
} else {
    $response = \Livewire\Livewire::mount('lista-productos');
    $html = $response->html();
    $_instance->logRenderedChild('en1h5Aj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ticom3\resources\views/products/list.blade.php ENDPATH**/ ?>