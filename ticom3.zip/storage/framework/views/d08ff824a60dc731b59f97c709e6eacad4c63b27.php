
<img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="">
<?php /**PATH C:\xampp\htdocs\ticom3\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>