<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center">
            <h2 class="text-xl font-semibold leading-tight text-gray-600">
                Empresas  :  <?php echo e($busine->razonsocial); ?>

            </h2>

           
        </div>




     <?php $__env->endSlot(); ?>



    <div class="container py-8 mx-auto">
        <figure class="mb-4">
           
        </figure>
             
        Empresa 

        <h1><?php echo e($busine->razonsocial); ?></h1>
        <h1><?php echo e($busine->razonsocial); ?></h1>
        <hr>

        <?php $__currentLoopData = $busine->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <p> <?php echo e($product->name); ?> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


       
        
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ticom3\resources\views/categories/showempresa.blade.php ENDPATH**/ ?>