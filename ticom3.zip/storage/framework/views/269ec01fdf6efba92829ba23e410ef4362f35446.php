<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center">
            <h2 class="text-xl font-semibold leading-tight text-gray-600">
                Lista de Categorias
            </h2>

           
        </div>




     <?php $__env->endSlot(); ?>

    <!-- This example requires Tailwind CSS v2.0+ -->

    <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
        <aside>

            <h2 class="mb-2 font-semibold text-center">Subcategorías</h2>

            <h2 class="mt-4 mb-2 font-semibold text-center">Marcas</h2>
         

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'mt-4','wire:click' => 'limpiar']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4','wire:click' => 'limpiar']); ?>
                Eliminar filtros
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </aside>
        <div class="md:col-span-2 lg:col-span-4">

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.table-responsive','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table-responsive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <div class="flex items-center px-6 py-4">


                    <div class="flex items-center">
                        <span>Mostrar </span>
                        <select wire:model="cant" class="ml-3 mr-3 form-control">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span>entradas</span>
                    </div>


                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','wire:model' => 'search','class' => 'w-full','placeholder' => 'Ingrese el nombre de la Categoria que quiere buscar']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wire:model' => 'search','class' => 'w-full','placeholder' => 'Ingrese el nombre de la Categoria que quiere buscar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                </div>

                <?php if($categories->count()): ?>
                    
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
        
                                <th scope="col"
                                    class="w-24 px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase cursor-pointer"
                                    wire:click="order('id')">
                                    ID

                                    
                                        <?php if($sort == 'id'): ?>
                                            <?php if($direction == 'asc'): ?>
                                             <i class="float-right mt-1 fas fa-sort-alpha-up-alt"></i>
                                            <?php else: ?>
                                              <i class="float-right mt-1 fas fa-sort-alpha-down-alt"></i>
                                            <?php endif; ?>
                                        <?php else: ?>
                                             <i class="float-right mt-1 fas fa-sort"></i>
                                        <?php endif; ?>
                                    

                                </th>
                                

                                <th scope="col"
                                    class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase cursor-pointer"
                                    wire:click="order('name')">
                                    Categoría
                                    
                                  
                                        <?php if($sort == 'name'): ?>
                                            <?php if($direction == 'asc'): ?>
                                            <i class="float-right mt-1 fas fa-sort-alpha-up-alt"></i>
                                            <?php else: ?>
                                            <i class="float-right mt-1 fas fa-sort-alpha-down-alt"></i>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <i class="float-right mt-1 fas fa-sort"></i>
                                        <?php endif; ?>
                                    
                                </th>

                                <th scope="col"
                                    class="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 uppercase">
                                    Numero de Empresas
                                </th>
                    
                                <th scope="col" class="relative px-6 py-3">
                                    <span class="sr-only">Ver Empresas</span>
                                    
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 w-10 h-10">
                                                
                                                <?php echo e($category->id); ?>

                                            </div>
                                        
                                        </div>
                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-500 whitespace-nowrap">
                                        <a href="<?php echo e(route('showepc', $category)); ?>"> <?php echo e($category->name); ?> </a>
                                    </td>


                                    <td class="px-6 py-4 text-sm text-gray-500 whitespace-nowrap">
                                        <a href="<?php echo e(route('showepc', $category)); ?>"> <?php echo e($category->business_count); ?> </a>
                                    </td>



                                    <td class="px-6 py-4 text-sm font-medium text-right whitespace-nowrap">
                                        
                                        <a href="<?php echo e(route('showepc', $category)); ?>" class="ml-2 font-semibold text-orange-500 hover:text-orange-400 hover:underline">Ver empresas</a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- More people... -->
                        </tbody>
                    </table>

                <?php else: ?>
                    <div class="px-6 py-4">
                        No hay ningún registro coincidente
                    </div>
                <?php endif; ?>

                <?php if($categories->hasPages()): ?>                
                    <div class="px-6 py-4">
                        <?php echo e($categories->links()); ?>

                    </div>
                    
                <?php endif; ?>
                    

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\ticom3\resources\views/livewire/show-categories.blade.php ENDPATH**/ ?>