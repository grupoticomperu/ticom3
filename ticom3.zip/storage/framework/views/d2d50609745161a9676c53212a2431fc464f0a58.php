<div>

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center">
            <h2 class="text-xl font-semibold leading-tight text-gray-600">
                Empresas de la categoria : <?php echo e($name); ?>

            </h2>

           
        </div>




     <?php $__env->endSlot(); ?>
    
    <section class="mt-16">

        <div class="grid grid-cols-1 px-4 mx-auto max-w-7xl sm:px-6 lg:px-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-8">
            <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $busine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article>
                    <figure>
                        <img class="object-cover w-full rounded-xl h-36" src="<?php echo e(asset('img/home/1.jpg')); ?>" alt="">
                    </figure>
                    <header class="mt-2">
                       
                        <a href="<?php echo e(route('showempresa', $busine)); ?> "> <?php echo e($busine->razonsocial); ?> </a>
                                                                               
                    </header>
                    <p class="text-sm text-gray-500">Lorem ipsum dolor sit amet consectetur adipisicing adipisicing adipisicing elit.</p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>

    </section>




</div>
<?php /**PATH C:\xampp\htdocs\ticom3\resources\views/livewire/show-empresasporcategoria.blade.php ENDPATH**/ ?>