<div>
    <h1>Lista de productos</h1>
</div>
<?php /**PATH C:\xampp\htdocs\ticom3\resources\views/livewire/admin/show-products.blade.php ENDPATH**/ ?>