<x-app-layout>
    

    <x-slot name="header">
        <div class="flex items-center">
            <h2 class="text-xl font-semibold leading-tight text-gray-600">
                Lista de Productos  :  
            </h2>
        </div>
    </x-slot>


    <div class="py-10 mx-auto max-w-7xl sm:px-6 lg:px-8">

       @livewire('lista-productos')


    </div>

</x-app-layout>