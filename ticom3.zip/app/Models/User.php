<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;
use Laravel\Jetstream\HasProfilePhoto;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Str;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens;
    use HasFactory;
    use HasProfilePhoto;
    use Notifiable;
    use TwoFactorAuthenticatable;
    use HasRoles;

    protected $fillable = [
        'name',
        'email',
        'password',
        'razonsocial',
        'slug',
        'description'
    ];


    public function getRouteKeyName()
    {
    	return 'slug';
    }


    public function setRazonsocialAttribute($razonsocial)
    {
        $this->attributes['razonsocial'] = $razonsocial;
        $this->attributes['slug'] = str::slug($razonsocial);

    }






    public function syncCategories($categories)
    {

        $categoryIds = collect($categories)->map(function($category){
            return Category::find($category) ? $category : Category::create(['name'=>$category])->id;
        });

        return $this->categories()->sync($categoryIds);
    }


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_recovery_codes',
        'two_factor_secret',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * The accessors to append to the model's array form.
     *
     * @var array
     */
    protected $appends = [
        'profile_photo_url',
    ];




    //Relacion uno a muchos
    public function products(){
        return $this->hasMany('App\Models\Product');
    }


    //Relacion muchos a muchos
    public function categories(){
        return $this->belongsToMany(Category::class);
    }







}
