<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Product;

class HomeController extends Controller
{
    public function __invoke()
    {
        $bussiness = User::orderBy('id', 'desc')->take(8)->get();
        $productos = Product::orderBy('id', 'desc')->take(12)->get();

    //dd($bussiness);
        return view('welcome', compact('bussiness', 'productos'));
    }
}
;